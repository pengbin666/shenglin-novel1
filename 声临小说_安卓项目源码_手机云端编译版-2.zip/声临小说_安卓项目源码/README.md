# 声临小说（ShengLin Novel）安卓项目起步版

这是 Android Studio 可打开的 Kotlin + Jetpack Compose 项目骨架。

## 当前已经包含
- 深色风格的「声临小说」界面
- 从安卓文件选择器导入 TXT
- 基础章节标题识别
- 角色配音配置界面示例
- 云端语音服务接入的安全边界说明

## 尚未完成（不能把当前版本当成完整有声小说软件）
- AI 自动识别角色、人物关系和情绪
- Azure Speech 云端合成服务
- 服务端 API（保护 Azure 密钥）
- 音频分段合并、缓存、下载
- 后台播放、锁屏控制、播放进度持久化
- APK 签名和正式发布

## 推荐下一步架构
Android App -> 自有 HTTPS 后端 -> Azure AI Speech
不要把 Azure Key 放在 Android 客户端。

建议后端接口：
- POST /v1/novels/analyze：提交章节文本，返回人物和段落角色标注
- POST /v1/speech/render：提交文本、角色 voice、style，返回音频任务 ID
- GET /v1/speech/tasks/{id}：查询生成状态
- GET /v1/audio/{id}：获取生成音频

## 本地打开
1. 在电脑安装 Android Studio。
2. 选择 Open，打开本项目文件夹。
3. 等待 Gradle 同步。
4. 连接安卓手机并开启开发者选项及 USB 调试。
5. 点击 Run。

当前项目是可继续开发的起步源码，不是已编译 APK。构建需要 Android Studio、Android SDK 和 Gradle 环境。


## 仅用安卓手机云端编译（无需电脑）
1. 在手机浏览器打开 GitHub 并登录/注册账号。
2. 新建一个 Repository，名称可填 `shenglin-novel`，设为 Private。
3. 在仓库中选择 Add file -> Upload files，将本压缩包解压后的所有项目文件上传（包括 `.github/workflows/android.yml`），提交到 `main` 分支。
4. 打开仓库的 Actions 页面，选择 `Build Android APK`，点击 `Run workflow`。
5. 等待任务完成，在运行记录底部的 Artifacts 下载 `shenglin-novel-debug-apk`，解压后得到 `app-debug.apk`。
6. Android 可能要求允许浏览器安装未知来源应用；只对自己刚编译的 APK 开启，安装后可关闭。

说明：GitHub Actions 的免费额度和界面可能随账号/地区变化；仓库不要上传任何云语音服务密钥。此流程编译的是调试版 APK，不是正式签名发布版。
