package com.shenglin.novel

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.InputStreamReader

private val Ink = Color(0xFF171923)
private val Panel = Color(0xFF242838)
private val Violet = Color(0xFFB49AFF)

data class Novel(val title: String, val chapters: List<String>, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShengLinApp() }
    }
}

@Composable
fun ShengLinApp() {
    val context = LocalContext.current
    var novel by remember { mutableStateOf<Novel?>(null) }
    var selectedTab by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("导入 TXT 小说，开始制作你的多人广播剧") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                }.orEmpty()
                val title = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "我的小说"
                val chapters = splitChapters(text)
                novel = Novel(title, chapters, text)
                message = "导入成功：${chapters.size} 个章节"
            } catch (e: Exception) {
                message = "读取失败，请确认文件为 UTF-8 编码的 TXT"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selectedTab == 0, { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("书架") })
                    NavigationBarItem(selectedTab == 1, { selectedTab = 1 },
                        icon = { Icon(Icons.Default.RecordVoiceOver, null) }, label = { Text("角色配音") })
                    NavigationBarItem(selectedTab == 2, { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("我的") })
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> LibraryScreen(
                    modifier = Modifier.padding(padding),
                    novel = novel,
                    message = message,
                    onImport = { picker.launch(arrayOf("text/plain", "text/*")) }
                )
                1 -> VoiceScreen(Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun LibraryScreen(modifier: Modifier, novel: Novel?, message: String, onImport: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("声临小说", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("让文字拥有生命", color = Color.LightGray, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(24.dp))
        Text("继续收听", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text(novel?.title ?: "还没有导入小说", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (novel != null) "${novel.chapters.size} 个章节" else "导入 TXT 小说，自动识别章节",
                    color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(14.dp))
                Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FileOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (novel == null) "导入 TXT 小说" else "更换小说")
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(message, color = Violet, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Text("章节列表", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        if (novel == null) {
            Text("导入后，章节会显示在这里。", color = Color.LightGray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(novel.chapters) { chapter ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Text(chapter, Modifier.fillMaxWidth().padding(14.dp), color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("角色配音", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("先为主要角色分配不同声音。正式合成需连接云端语音服务。",
            color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(20.dp))
        VoiceRow("旁白", "沉稳、富有叙事感", "zh-CN-YunxiNeural")
        VoiceRow("男主角", "成熟、低沉", "zh-CN-YunyangNeural")
        VoiceRow("女主角", "自然、温柔", "zh-CN-XiaoxiaoNeural")
        VoiceRow("其他角色", "待识别后分配", "自动分配")
        Spacer(Modifier.height(16.dp))
        Text("提示：角色识别与云端音频生成接口将在后续版本接入。",
            color = Violet, fontSize = 13.sp)
    }
}

@Composable
fun VoiceRow(role: String, style: String, voice: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.RecordVoiceOver, null, tint = Violet, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(role, fontWeight = FontWeight.Bold)
                Text(style, color = Color.LightGray, fontSize = 12.sp)
            }
            Text(voice, color = Violet, fontSize = 11.sp)
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("我的", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("声临小说 · 版本 0.1.0", color = Color.LightGray)
        Text("云端语音服务尚未配置。请勿将服务密钥直接写入 APK。",
            color = Violet, modifier = Modifier.padding(top = 12.dp))
    }
}

fun splitChapters(text: String): List<String> {
    val regex = Regex("(?m)^\\s*(第[零〇一二三四五六七八九十百千万0-9]+[章节回卷].*)$")
    val matches = regex.findAll(text).toList()
    if (matches.isEmpty()) return listOf("全文")
    return matches.map { it.groupValues[1].trim() }.distinct()
}
